function [fake_output]=callSim(timestep,Meas)
%% Notes
%% Inputs
% timestep
%   User should put callSim function in a loop, where timestep=0:1:end
% Meas:
%     m_sup = Meas(1) :       discharge air mass flow rate [kg/s]
%     T_sup = Meas(2) :       discharge air temperature [°C]
%     w_sup = Meas(3) :       discharge air humidity ratio [kg/kg]
%% Outputs
% ZoneInfo
%   T_z: (Simulated) Zone air temperature [C]
%   w_z: Zone humidity ratio [kgwater/kgair]
%   T_out: Outdoor air temperature [C]
%   w_out: Outdoor air humidty ration [kgwater/kgair]
%% Initialization
persistent stepsize SimulinkName

if timestep==0
    % time (day of year)
    DOY = 238;  % day of year (8/26/15 -> 238)
    startTime_forEnergyPlus=86400*(DOY-2);   % EPlus simulation start time in seconds
    stopTime=86400*DOY;     % EPlus simulation end time in seconds
    % parameters
    stepsize=60;    % step size of each timestep (in seconds)
    % directory
    %par_dir = fileparts(strcat(pwd,'\callSim.m'));
    % add EnergyPlus 9.5 Path
    %{
    % add OBMsubfuntion to path
    addpath(strcat(par_dir,'\OBM'));
    % add Airflow ANN model to path
    addpath(strcat(par_dir,'\OBM\AirflowANNmodel'));
    % add DB function to path
    addpath(strcat(par_dir,'\DB'));
    % add virtual building to path
    addpath(strcat(par_dir,'\VB'));
    % add control models to path
    addpath(strcat(par_dir,'\CTRL'));
    %}
    %% run virtual building model
    % Simulink file name
    SimulinkName = 'SmallOffice_Atlanta_Occ';
    % open Simulink
    open_system(SimulinkName);
    % set Simulink start time and stop time at the initial call
    set_param(bdroot,'StartTime',string(startTime_forEnergyPlus),'StopTime',string(stopTime));
    % set initial input values
    set_param([SimulinkName,'/m_flow'], 'Value', num2str(Meas(1)));
    set_param([SimulinkName,'/T_sup'], 'Value', num2str(Meas(2)));
    set_param([SimulinkName,'/HR_sup'], 'Value', num2str(Meas(3)));
    % start Simulink
    set_param(bdroot,'SimulationCommand','start');

    for i_firstday=0:(1440-1)
        set_param(bdroot,'SimulationCommand','pause');
        set_param(bdroot,'SimulationCommand','continue');
    end

else
    % continue Simulink
    set_param(bdroot,'SimulationCommand','continue');
end
% pause Simulink
set_param(bdroot,'SimulationCommand','pause');
%{
%% Get ZoneInfo from DB
ZoneInfo=zeros(1,length(ZoneInfoLabel));
ret=find(conn,CollName,'Query',['{"Timestep":',num2str(timestep),...
    ',"DocType":"SimData"}'],'Projection',ZIFields);
for i=1:length(ZoneInfoLabel)
    ZoneInfo(i)=ret.(char(ZoneInfoLabel(i)));
end
%}
%% Finalization
if (timestep==86400/stepsize)
    set_param(bdroot,'SimulationCommand','stop');
    save_system(SimulinkName);
    close_system(SimulinkName);
end
%%
fake_output=1;
end