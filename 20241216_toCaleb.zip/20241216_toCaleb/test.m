clc,clear all
Meas=[0, 12, 0.1];
for t=0:1440
    [fake_output]=callSim(t,Meas);
end