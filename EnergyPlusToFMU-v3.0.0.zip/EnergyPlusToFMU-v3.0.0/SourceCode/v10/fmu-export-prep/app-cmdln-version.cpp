//--- Version string for command-line app to export an EnergyPlus simulation as an FMU.


//--- Copyright notice.
//
//   Please see the header file.


//--- Includes.
//
#include "app-cmdln-version.h"


//--- Global variables.
//
const char *const gp_cmdln_versionStr = "0.1";
